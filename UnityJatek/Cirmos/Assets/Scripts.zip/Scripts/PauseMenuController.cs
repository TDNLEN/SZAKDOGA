using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseMenuController : MonoBehaviour
{
    [Header("Refs")]
    public GameObject pauseMenuUI; // ide h�zd be a PauseMenu GameObjectet
    public CanvasGroup dimBackground; // opcion�lis, ha fokozatosan s�t�t�ted

    private bool isPaused = false;

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (isPaused)
                ResumeGame();
            else
                PauseGame();
        }
    }

    public void PauseGame()
    {
        if (pauseMenuUI == null) return;

        pauseMenuUI.SetActive(true);
        Time.timeScale = 0f; // j�t�k meg�ll
        isPaused = true;

        // ha van CanvasGroup az els�t�t�t�shez:
        if (dimBackground != null)
        {
            dimBackground.alpha = 0.5f; // �ttetsz� fekete
        }
    }

    public void ResumeGame()
    {
        if (pauseMenuUI == null) return;

        pauseMenuUI.SetActive(false);
        Time.timeScale = 1f; // j�t�k �jraindul
        isPaused = false;
    }

    public void QuitGame()
    {
        Time.timeScale = 1f; // biztos, ami biztos
        SceneManager.LoadScene("Main_menu"); // vissza a f�men�be
    }
}
