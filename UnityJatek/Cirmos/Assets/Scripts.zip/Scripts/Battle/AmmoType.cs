// Assets/Scripts/Ammo/AmmoType.cs
public enum AmmoType
{
    Handgun,
    Shotgun,
    Rifle
    // k�s�bb ide j�het: Shotgun, Rifle, Energy, stb.
}
