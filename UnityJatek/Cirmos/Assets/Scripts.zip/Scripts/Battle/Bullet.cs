using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float speed = 20f;
    public int damage = 1;
    public float maxDistance = 8f;

    private Vector2 direction;
    private Vector2 startPos;

    // Ranged fegyver innen h�vja
    public void Init(Vector2 dir, float spd, int dmg, float range)
    {
        direction = dir.normalized;
        speed = spd;
        damage = dmg;
        maxDistance = range;
        startPos = transform.position;

        // sprite ford�t�sa a halad�si ir�nyba (opcion�lis, de j�l n�z ki)
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.Euler(0f, 0f, angle);
    }

    private void Update()
    {
        // mozg�s
        transform.position += (Vector3)(direction * speed * Time.deltaTime);

        // t�v v�g�n t�r�lj�k
        if (Vector2.Distance(startPos, transform.position) >= maxDistance)
            Destroy(gameObject);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // ne a playert l�j�k sz�t (ha enemy bullet, akkor majd m�st csin�l)
        if (other.CompareTag("Player")) return;

        // enemy sebz�s
        var zh = other.GetComponent<ZombieHealth>();
        if (zh == null) zh = other.GetComponentInParent<ZombieHealth>();

        if (zh != null)
        {
            zh.TakeDamage(damage, transform.position);
            Destroy(gameObject);
            return;
        }

        // egy�b t�rgyba csap�dva is elt�nhet
        Destroy(gameObject);
    }
}
