using UnityEngine;
using UnityEngine.UI;

public class HotbarUI : MonoBehaviour
{
    [Header("References")]
    public Image[] slotBGs;        // Slot0..Slot4 h�tt�r (Image)
    public Image[] slotIcons;      // Slot0..Slot4/Icon (Image)
    public RectTransform selector; // kijel�l� keret

    [Header("Colors")]
    public Color normalColor = new Color(1f, 1f, 1f, 0.2f);
    public Color selectedColor = new Color(1f, 1f, 1f, 0.5f);

    public int SelectedIndex { get; private set; } = 0;

    private void Start()
    {
        // Biztons�g: az ikonok �s a slotok sz�ma egyezzen
        if (slotIcons != null && slotBGs != null && slotIcons.Length != slotBGs.Length)
        {
            Debug.LogWarning("[HotbarUI] slotIcons �s slotBGs hossza elt�r � ellen�rizd az Inspectorban!");
        }

        // ikonok alap�llapot
        if (slotIcons != null)
        {
            for (int i = 0; i < slotIcons.Length; i++)
                SetIcon(i, null);
        }

        if (slotBGs != null && slotBGs.Length > 0)
            Select(0);
        else
            Debug.LogError("[HotbarUI] slotBGs nincs felt�ltve az Inspectorban.");
    }

    public void SetIcon(int index, Sprite sprite)
    {
        if (slotIcons == null || index < 0 || index >= slotIcons.Length) return;

        var img = slotIcons[index];
        img.sprite = sprite;
        img.enabled = (sprite != null);
    }

    public void ClearIcon(int index) => SetIcon(index, (Sprite)null);

    public void Select(int index)
    {
        if (slotBGs == null || slotBGs.Length == 0)
        {
            Debug.LogError("[HotbarUI] slotBGs �res � k�sd be a Slot k�peket az Inspectorban!");
            return;
        }

        index = Mathf.Clamp(index, 0, slotBGs.Length - 1);
        SelectedIndex = index;

        // Selector �trak�sa a kiv�lasztott slotra
        if (selector)
        {
            selector.SetParent(slotBGs[SelectedIndex].transform, false);
            selector.anchoredPosition = Vector2.zero;
        }

        // h�tt�r sz�nkiemel�s
        for (int i = 0; i < slotBGs.Length; i++)
            slotBGs[i].color = (i == SelectedIndex) ? selectedColor : normalColor;
    }

    public void SelectNext(int dir)
    {
        if (slotBGs == null || slotBGs.Length == 0) return;

        int i = (SelectedIndex + dir) % slotBGs.Length;
        if (i < 0) i += slotBGs.Length;
        Select(i);
    }
}
