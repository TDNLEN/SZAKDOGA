using UnityEngine;

public class BuildingSpawner : MonoBehaviour
{
    public GameObject buildingPrefab;   // ide h�zd be a k�sz �p�let prefab-ot
    public float spacing = 1000f;       // minden 1000 egys�gen legyen �p�let
    public int spawnCount = 10;         // mennyit hozzon l�tre el�re
    public float buildingY = 0f;        // milyen magass�gban legyen (a s�nekhez igaz�tva)

    private void Start()
    {
        SpawnBuildings();
    }

    private void SpawnBuildings()
    {
        if (buildingPrefab == null)
        {
            Debug.LogError("Nincs be�ll�tva a buildingPrefab!");    
            return;
        }

        for (int i = 1; i <= spawnCount; i++)
        {
            float x = i * spacing;
            Vector3 pos = new Vector3(x, buildingY, 0f);

            Instantiate(buildingPrefab, pos, Quaternion.identity);
        }
    }
}
