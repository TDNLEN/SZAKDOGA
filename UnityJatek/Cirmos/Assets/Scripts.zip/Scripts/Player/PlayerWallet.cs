using UnityEngine;
using TMPro;

public class PlayerWallet : MonoBehaviour
{
    [Header("Money")]
    public int coins = 0;                     // kezdetben 0 p�nz

    [Header("UI")]
    public TextMeshProUGUI coinText;         // ide h�zd a UI sz�veget (pl. "CoinsText")
    public GameObject coinPanel;             // opcion�lis: a h�tt�r panel (ha van)

    private void Start()
    {
        UpdateUI();
    }

    public void AddCoins(int amount)
    {
        if (amount <= 0) return;

        coins += amount;
        UpdateUI();
    }

    public bool TrySpend(int amount)
    {
        if (coins < amount) return false;

        coins -= amount;
        UpdateUI();
        return true;
    }

    private void UpdateUI()
    {
        if (coinText != null)
            coinText.text = coins.ToString();

        // ha akarod: panel elrejt�se, ha 0 a p�nz
        if (coinPanel != null)
            coinPanel.SetActive(true);   // vagy: coins > 0-ra �ll�tsd, ha �gy akarod elt�ntetni
    }
}
